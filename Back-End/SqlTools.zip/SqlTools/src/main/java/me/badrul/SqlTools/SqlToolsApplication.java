package me.badrul.SqlTools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlToolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqlToolsApplication.class, args);
	}

}

